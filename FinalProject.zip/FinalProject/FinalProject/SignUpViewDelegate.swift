import Foundation

protocol SignUpViewDelegate {
    func goToLogin()
}

