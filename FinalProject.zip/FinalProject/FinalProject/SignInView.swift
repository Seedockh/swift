import UIKit

class SignInView: UIView, SignInViewDelegate {
    @IBOutlet weak var signInView: SignInView!
    @IBOutlet weak var signUpView: SignUpView!
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        commonInit()
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        commonInit()
    }
    
    private func commonInit() {
        Bundle.main.loadNibNamed("SignInView", owner: self, options: nil)
        addSubview(signInView)
        signInView.frame = self.bounds
        signInView.autoresizingMask = [.flexibleHeight, .flexibleWidth]
    }

    func goToRegister() {
        signUpView.isHidden = false
        signInView.isHidden = true
        print("SignUp : \(signUpView.isHidden)")
        print("SignIn : \(signInView.isHidden)")
    }
}
