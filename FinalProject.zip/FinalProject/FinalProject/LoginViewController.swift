import UIKit

class LoginViewController: UIViewController {
    
    @IBOutlet weak var signInView: SignInView!
    @IBOutlet weak var signUpView: SignUpView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    @IBAction func goToLogin() {
        print("GOTO LOGIN FROM CONTROLLER")
        signUpView.goToLogin()
    }
    
    @IBAction func goToRegister() {
        print("GOTO REGISTER FROM CONTROLLER")
        signInView.goToRegister()
    }

}
