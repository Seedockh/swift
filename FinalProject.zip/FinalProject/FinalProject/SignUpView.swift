import UIKit

class SignUpView: UIView, SignUpViewDelegate {
    @IBOutlet weak var signInView: SignInView!
    @IBOutlet weak var signUpView: SignUpView!
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        commonInit()
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        commonInit()
    }
    
    private func commonInit() {
        Bundle.main.loadNibNamed("SignUpView", owner: self, options: nil)
        addSubview(signUpView)
        signUpView.frame = self.bounds
        signUpView.autoresizingMask = [.flexibleHeight, .flexibleWidth]
    }
    
    func goToLogin() {
        signUpView.isHidden = true
        signInView.isHidden = false
        print("SignUp : \(signUpView.isHidden)")
        print("SignIn : \(signInView.isHidden)")
    }
}
