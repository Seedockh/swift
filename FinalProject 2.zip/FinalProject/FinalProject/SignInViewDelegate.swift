import Foundation

protocol SignInViewDelegate {
    func goToRegister()
}
